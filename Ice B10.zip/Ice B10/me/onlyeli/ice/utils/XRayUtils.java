package me.onlyeli.ice.utils;

public class XRayUtils
{
    public static int xrayOpacity;
    public static boolean isXRay;
    
    static {
        XRayUtils.xrayOpacity = 900;
    }
}
