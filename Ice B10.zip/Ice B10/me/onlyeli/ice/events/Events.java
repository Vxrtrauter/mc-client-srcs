package me.onlyeli.ice.events;

public abstract class Events
{
}
