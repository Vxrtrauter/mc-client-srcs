package me.onlyeli.ice.events;

import me.onlyeli.eventapi.events.callables.EventCancellable;

public class EventUpdatePreMotion  extends EventCancellable
{
	  public float yaw;
	  public float pitch;
	  
	  public EventUpdatePreMotion()
	  {
	
	  }

	 



}
