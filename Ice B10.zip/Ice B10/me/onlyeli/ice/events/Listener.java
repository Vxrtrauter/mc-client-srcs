package me.onlyeli.ice.events;

import java.util.EventListener;


public interface Listener extends EventListener {

	public void onEvent(Events event);
	
}
