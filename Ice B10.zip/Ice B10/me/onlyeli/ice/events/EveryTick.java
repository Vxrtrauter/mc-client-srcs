package me.onlyeli.ice.events;

import me.onlyeli.ice.events.Events;

public class EveryTick extends Events
{
}
