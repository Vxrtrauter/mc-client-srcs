package me.onlyeli.ice.events;

import me.onlyeli.eventapi.events.Event;

public class EventStepConfirm implements Event
{}
