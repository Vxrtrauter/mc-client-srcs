package info.spicyclient.modules.memes;

import org.lwjgl.input.Keyboard;

import info.spicyclient.modules.Module;

public class Tophats extends Module {

	public Tophats() {
		super("Tophats", Keyboard.KEY_NONE, Category.MEMES);
		// TODO Auto-generated constructor stub
	}

}
