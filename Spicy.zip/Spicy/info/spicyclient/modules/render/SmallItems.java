package info.spicyclient.modules.render;

import org.lwjgl.input.Keyboard;

import info.spicyclient.modules.Module;

public class SmallItems extends Module {

	public SmallItems() {
		super("SmallItems", Keyboard.KEY_NONE, Category.RENDER);
		// TODO Auto-generated constructor stub
	}
	
}
