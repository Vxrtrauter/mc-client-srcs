package info.spicyclient.events;

public enum EventDirection {
	
	INCOMING,
	OUTGOING
	
}
