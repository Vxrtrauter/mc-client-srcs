package info.spicyclient.events.listeners;

import info.spicyclient.events.Event;

public class EventUpdate extends Event<EventUpdate> {
	
	
	
}
