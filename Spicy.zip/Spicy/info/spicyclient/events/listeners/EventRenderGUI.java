package info.spicyclient.events.listeners;

import info.spicyclient.events.Event;

public class EventRenderGUI extends Event<EventRenderGUI> {
	
	
	
}
