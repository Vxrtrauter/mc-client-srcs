package info.spicyclient.events.listeners;

import info.spicyclient.events.Event;

public class EventServerSettingWorldTime extends Event<EventServerSettingWorldTime> {
	
}
