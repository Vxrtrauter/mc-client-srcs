package info.spicyclient.events.listeners;

import info.spicyclient.events.Event;

public class EventGetBlockReach extends Event<EventGetBlockReach> {
	
	public float reach = -1;
	
}
