package info.spicyclient.events.listeners;

import info.spicyclient.events.Event;
import net.minecraft.entity.player.EntityPlayerMP;

public class EventServerSetYawAndPitch extends Event<EventServerSetYawAndPitch> {
	
	public boolean notify = true;
	
}
