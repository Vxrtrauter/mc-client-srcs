package info.spicyclient.events;

public enum EventType {
	
	BEFOREPRE,
	PRE,
	BEFOREPOST,
	POST
	
}
