package info.spicyclient.blockCoding;

public class CustomModule {
	
	public CustomModule(String name) {
		
		this.name = name;
		
	}
	
	public String name = "";
	
}
