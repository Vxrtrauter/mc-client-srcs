package info.spicyclient.blockCoding;

public enum Color {
	
	RED(0xffff6052),
	GREEN(0xff52ff8f),
	BLUE(0xff52baff),
	YELLOW(0xffffe852),
	PINK(0xffff6bfd);
	
	public int color;
	
	Color(int color){
		
		this.color = color;
		
	}
	
}
