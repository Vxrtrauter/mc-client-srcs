package info.spicyclient.blockCoding.impl;

import info.spicyclient.blockCoding.Block;
import info.spicyclient.blockCoding.Color;

public class BlockMotion extends Block {

	public BlockMotion() {
		super(Color.BLUE);
	}

}
