package info.spicyclient.cosmetics;

public class ReadMe {
	
	/*
	 * 
	 * Big thanks to Eric Golde for making a tutorial on how to add cosmetics, I never would be able to add cosmetics into the client without him
	 * Go subscribe to him on youtube or check out some of his videos
	 * I'm sorry i forgot to credit him in release B1
	 * Go check out his youtube channel here >>> https://www.youtube.com/user/egold555
	 * 
	 */
	
}
