/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.viamcp.viafabric.handler;

public class CommonTransformer {
    public static final String HANDLER_DECODER_NAME = "via-decoder";
    public static final String HANDLER_ENCODER_NAME = "via-encoder";
}

