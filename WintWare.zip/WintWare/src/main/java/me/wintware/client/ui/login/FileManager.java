/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.ui.login;

import java.io.File;

public class FileManager {
    public static File Wint;
}

