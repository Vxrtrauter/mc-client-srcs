/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.event;

public interface Cancellable {
    boolean isCancelled();

    void setCancelled(boolean var1);
}

