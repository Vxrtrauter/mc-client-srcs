/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.viamcp.viamcp.exemple;

public class NetworkManagerExemple {
    public void setCompressionTreshold(int treshold) {
    }
}

