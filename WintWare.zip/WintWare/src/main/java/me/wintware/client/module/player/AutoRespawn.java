/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.module.player;

import me.wintware.client.module.Category;
import me.wintware.client.module.Module;

public class AutoRespawn
extends Module {
    public AutoRespawn() {
        super("AutoRespawn", Category.Player);
    }
}

