/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.module.visual;

import me.wintware.client.module.Category;
import me.wintware.client.module.Module;

public class HurtCam
extends Module {
    public HurtCam() {
        super("HurtCam", Category.Visuals);
    }
}

