/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.module.visual;

import me.wintware.client.module.Category;
import me.wintware.client.module.Module;

public class NoPumkinOverlay
extends Module {
    public NoPumkinOverlay() {
        super("NoPumpkinOverlay", Category.Visuals);
    }
}

