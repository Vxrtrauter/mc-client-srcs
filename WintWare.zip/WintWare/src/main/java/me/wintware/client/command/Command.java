/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.command;

@FunctionalInterface
public interface Command {
    void execute(String... var1);
}

