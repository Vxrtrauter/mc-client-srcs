/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.module.combat;

import me.wintware.client.module.Category;
import me.wintware.client.module.Module;

public class KeepSprint
extends Module {
    public KeepSprint() {
        super("KeepSprint", Category.Combat);
    }
}

