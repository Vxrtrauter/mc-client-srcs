/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.viamcp.viamcp.exemple;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;

public class MultiPlayerGuiExemple {
    public void createButtons() {
    }

    protected void actionPerformed(GuiButton button) throws IOException {
    }
}

