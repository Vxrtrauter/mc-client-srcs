/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.utils.other;

import net.minecraft.client.Minecraft;

public interface MinecraftHelper {
    Minecraft mc = Minecraft.getMinecraft();
}

