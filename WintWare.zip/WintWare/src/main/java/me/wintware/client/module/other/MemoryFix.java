/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.module.other;

import me.wintware.client.module.Category;
import me.wintware.client.module.Module;

public class MemoryFix
extends Module {
    public MemoryFix() {
        super("Optimization", Category.World);
    }
}

