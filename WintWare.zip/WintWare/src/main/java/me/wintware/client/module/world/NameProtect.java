/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.module.world;

import me.wintware.client.module.Category;
import me.wintware.client.module.Module;

public class NameProtect
extends Module {
    public NameProtect() {
        super("NameProtect", Category.World);
    }
}

