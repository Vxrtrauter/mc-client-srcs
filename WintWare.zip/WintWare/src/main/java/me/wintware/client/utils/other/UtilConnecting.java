/*
 * Decompiled with CFR 0.150.
 */
package me.wintware.client.utils.other;

import net.minecraft.client.multiplayer.ServerData;

public class UtilConnecting {
    public static ServerData serverData;
}

