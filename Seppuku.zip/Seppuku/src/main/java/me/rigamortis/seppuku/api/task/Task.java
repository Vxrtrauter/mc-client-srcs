package me.rigamortis.seppuku.api.task;

public interface Task {

    boolean isOnline();

    void setOnline(boolean online);
}
