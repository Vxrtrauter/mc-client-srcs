package me.rigamortis.seppuku.api.event.world;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/10/2019 @ 2:53 AM.
 */
public class EventCollideSoulSand extends EventCancellable {
}
