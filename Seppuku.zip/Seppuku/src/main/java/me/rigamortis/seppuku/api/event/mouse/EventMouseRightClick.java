package me.rigamortis.seppuku.api.event.mouse;

import me.rigamortis.seppuku.api.event.EventCancellable;

public class EventMouseRightClick extends EventCancellable {
}
