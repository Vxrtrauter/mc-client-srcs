package me.rigamortis.seppuku.api.event.render;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 12/17/2019 @ 1:23 AM.
 */
public class EventRenderSky extends EventCancellable {
}
