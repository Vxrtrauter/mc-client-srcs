package me.rigamortis.seppuku.api.task.rotation;

import me.rigamortis.seppuku.api.task.basic.BasicTaskFactory;

public final class RotationTaskFactory extends BasicTaskFactory<RotationTask> {

}
