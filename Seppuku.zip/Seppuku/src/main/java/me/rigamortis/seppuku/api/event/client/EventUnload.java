package me.rigamortis.seppuku.api.event.client;

/**
 * Author Seth
 * 7/19/2019 @ 9:44 PM.
 */
public final class EventUnload {
}
