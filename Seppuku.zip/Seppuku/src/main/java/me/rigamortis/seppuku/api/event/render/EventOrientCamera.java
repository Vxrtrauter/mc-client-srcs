package me.rigamortis.seppuku.api.event.render;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 7/22/2019 @ 8:26 AM.
 */
public class EventOrientCamera extends EventCancellable {
}
