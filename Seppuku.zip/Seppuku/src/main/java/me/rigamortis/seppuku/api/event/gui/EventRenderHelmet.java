package me.rigamortis.seppuku.api.event.gui;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/8/2019 @ 8:19 PM.
 */
public class EventRenderHelmet extends EventCancellable {
}
