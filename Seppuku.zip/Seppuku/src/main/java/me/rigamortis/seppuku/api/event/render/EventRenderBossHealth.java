package me.rigamortis.seppuku.api.event.render;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 9/30/2019 @ 6:45 AM.
 */
public class EventRenderBossHealth extends EventCancellable {
}
