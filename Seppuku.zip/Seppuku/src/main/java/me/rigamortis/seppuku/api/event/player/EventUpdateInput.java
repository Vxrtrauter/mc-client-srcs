package me.rigamortis.seppuku.api.event.player;

/**
 * Author Seth
 * 4/10/2019 @ 3:15 AM.
 */
public class EventUpdateInput {
}
