package me.rigamortis.seppuku.api.event.player;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/8/2019 @ 4:34 PM.
 */
public class EventCloseScreen extends EventCancellable {
}
