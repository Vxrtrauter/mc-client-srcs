package me.rigamortis.seppuku.api.event.minecraft;

import me.rigamortis.seppuku.api.event.EventStageable;

/**
 * Author Seth
 * 4/5/2019 @ 6:24 PM.
 */
public class EventRunTick extends EventStageable {

    public EventRunTick(EventStage stage) {
        super(stage);
    }

}
