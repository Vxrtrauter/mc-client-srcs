package me.rigamortis.seppuku.api.event.entity;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 4/9/2019 @ 11:42 AM.
 */
public class EventSteerEntity extends EventCancellable {
}
