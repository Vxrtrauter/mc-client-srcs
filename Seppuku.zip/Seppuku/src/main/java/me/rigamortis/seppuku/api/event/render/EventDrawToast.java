package me.rigamortis.seppuku.api.event.render;

import me.rigamortis.seppuku.api.event.EventCancellable;

public class EventDrawToast extends EventCancellable {
}
