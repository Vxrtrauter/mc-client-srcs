package me.rigamortis.seppuku.api.event.player;

/**
 * Author Seth
 * 5/24/2019 @ 3:47 AM.
 */
public class EventStep {
}
