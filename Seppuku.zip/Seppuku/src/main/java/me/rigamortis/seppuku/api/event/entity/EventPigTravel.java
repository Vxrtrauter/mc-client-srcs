package me.rigamortis.seppuku.api.event.entity;

import me.rigamortis.seppuku.api.event.EventCancellable;

/**
 * Author Seth
 * 6/27/2019 @ 6:30 AM.
 */
public class EventPigTravel extends EventCancellable {
}
