// 
// Decompiled by Procyon v0.5.36
// 

package com.darkmagician6.eventapi;

public final class EventAPI
{
    public static final String VERSION;
    public static final String[] AUTHORS;
    
    static {
        VERSION = String.format("%s-%s", "0.7", "beta");
        AUTHORS = new String[] { "DarkMagician6" };
    }
    
    private EventAPI() {
    }
}
