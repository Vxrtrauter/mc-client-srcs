// 
// Decompiled by Procyon v0.5.36
// 

package com.darkmagician6.eventapi.events;

public interface Cancellable
{
    boolean isCancelled();
    
    void setCancelled(final boolean p0);
}
