// 
// Decompiled by Procyon v0.5.36
// 

package com.google.common.annotations;

import java.lang.annotation.Annotation;

@GwtCompatible
public @interface VisibleForTesting {
}
