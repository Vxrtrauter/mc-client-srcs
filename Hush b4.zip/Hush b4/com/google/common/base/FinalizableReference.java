// 
// Decompiled by Procyon v0.5.36
// 

package com.google.common.base;

public interface FinalizableReference
{
    void finalizeReferent();
}
