// 
// Decompiled by Procyon v0.5.36
// 

package com.google.common.io;

public enum FileWriteMode
{
    APPEND;
}
