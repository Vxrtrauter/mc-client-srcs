// 
// Decompiled by Procyon v0.5.36
// 

package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated = true)
class ForwardingImmutableCollection
{
    private ForwardingImmutableCollection() {
    }
}
