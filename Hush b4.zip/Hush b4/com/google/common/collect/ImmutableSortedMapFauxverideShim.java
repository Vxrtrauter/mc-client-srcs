// 
// Decompiled by Procyon v0.5.36
// 

package com.google.common.collect;

abstract class ImmutableSortedMapFauxverideShim<K, V> extends ImmutableMap<K, V>
{
    @Deprecated
    public static <K, V> ImmutableSortedMap.Builder<K, V> builder() {
        throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public static <K, V> ImmutableSortedMap<K, V> of(final K k1, final V v1) {
        throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public static <K, V> ImmutableSortedMap<K, V> of(final K k1, final V v1, final K k2, final V v2) {
        throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public static <K, V> ImmutableSortedMap<K, V> of(final K k1, final V v1, final K k2, final V v2, final K k3, final V v3) {
        throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public static <K, V> ImmutableSortedMap<K, V> of(final K k1, final V v1, final K k2, final V v2, final K k3, final V v3, final K k4, final V v4) {
        throw new UnsupportedOperationException();
    }
    
    @Deprecated
    public static <K, V> ImmutableSortedMap<K, V> of(final K k1, final V v1, final K k2, final V v2, final K k3, final V v3, final K k4, final V v4, final K k5, final V v5) {
        throw new UnsupportedOperationException();
    }
}
