package com.ihl.client.commands.exceptions;

public class CommandException extends Exception {

}
