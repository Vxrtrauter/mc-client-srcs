package com.ihl.client.event;

public class EventPlayerUpdate extends Event {

    public EventPlayerUpdate(Type type) {
        super(type);
    }

}
