// 
// Decompiled by Procyon v0.5.30
// 

package assets.minecraft.euphoria;

import net.minecraft.util.ResourceLocation;

public class Texture
{
    public static final ResourceLocation backgroundImage;
    
    static {
        backgroundImage = new ResourceLocation("euphoria/background.png");
    }
}
