package me.bebeli555.cookieclient.events.entity;

import me.bebeli555.cookieclient.events.bus.Cancellable;

public class GetEntitiesEvent extends Cancellable {

}
