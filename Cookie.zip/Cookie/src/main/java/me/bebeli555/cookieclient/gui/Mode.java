package me.bebeli555.cookieclient.gui;

public enum Mode {
	BOOLEAN(),
	INTEGER(),
	DOUBLE(),
	TEXT(),
	MODE(),
	LABEL();
}
