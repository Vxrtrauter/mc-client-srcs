package org.kamiblue.client.setting

import org.kamiblue.commons.interfaces.Nameable

interface GenericConfigClass : Nameable