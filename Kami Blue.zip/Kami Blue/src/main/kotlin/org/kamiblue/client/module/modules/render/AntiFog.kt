package org.kamiblue.client.module.modules.render

import org.kamiblue.client.module.Category
import org.kamiblue.client.module.Module

internal object AntiFog : Module(
    name = "AntiFog",
    description = "Disables or reduces fog",
    category = Category.RENDER
)