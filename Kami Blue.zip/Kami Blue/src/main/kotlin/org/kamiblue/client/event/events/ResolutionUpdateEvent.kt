package org.kamiblue.client.event.events

import org.kamiblue.client.event.Event

class ResolutionUpdateEvent(val width: Int, val height: Int) : Event