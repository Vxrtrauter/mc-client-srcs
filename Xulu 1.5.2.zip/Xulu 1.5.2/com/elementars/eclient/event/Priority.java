// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.event;

public class Priority
{
    public static final byte FIRST = 0;
    public static final byte SECOND = 1;
    public static final byte THIRD = 2;
    public static final byte FOURTH = 3;
    public static final byte FIFTH = 4;
    public static final byte[] VALUE_ARRAY;
    
    static {
        VALUE_ARRAY = new byte[] { 0, 1, 2, 3, 4 };
    }
}
