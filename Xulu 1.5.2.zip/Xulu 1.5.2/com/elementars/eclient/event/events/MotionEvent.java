// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.event.events;

import com.elementars.eclient.event.Event;

public class MotionEvent extends Event
{
    public static class Pre extends MotionEvent
    {
    }
    
    public static class Post extends MotionEvent
    {
    }
}
