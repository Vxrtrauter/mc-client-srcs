// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.module.misc;

import com.elementars.eclient.module.Category;
import com.elementars.eclient.module.Module;

public class CameraClip extends Module
{
    public CameraClip() {
        super("CameraClip", "Allows camera to clip in blocks", 0, Category.MISC, true);
    }
}
