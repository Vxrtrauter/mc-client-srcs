// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.module;

public enum Category
{
    COMBAT, 
    MOVEMENT, 
    RENDER, 
    PLAYER, 
    MISC, 
    HUD, 
    CORE, 
    DUMMY, 
    HIDDEN;
}
