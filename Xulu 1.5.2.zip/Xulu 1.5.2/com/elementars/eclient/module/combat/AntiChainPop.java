// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.module.combat;

import com.elementars.eclient.module.Category;
import com.elementars.eclient.module.Module;

public class AntiChainPop extends Module
{
    public AntiChainPop() {
        super("AntiChainPop", "Does exactly what you think it does", 0, Category.COMBAT, true);
    }
}
