// 
// Decompiled by Procyon v0.5.36
// 

package com.elementars.eclient.enemy;

public class Enemy
{
    String username;
    
    public Enemy(final String username) {
        this.username = username;
    }
    
    public String getUsername() {
        return this.username;
    }
}
