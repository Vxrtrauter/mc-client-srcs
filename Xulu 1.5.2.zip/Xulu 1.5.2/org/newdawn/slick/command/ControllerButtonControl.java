// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick.command;

public class ControllerButtonControl extends ControllerControl
{
    public ControllerButtonControl(final int controllerIndex, final int button) {
        super(controllerIndex, 0, button);
    }
}
