// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

public interface KeyListener extends ControlledInputReciever
{
    void keyPressed(final int p0, final char p1);
    
    void keyReleased(final int p0, final char p1);
}
