// 
// Decompiled by Procyon v0.5.36
// 

package org.newdawn.slick;

public interface InputListener extends MouseListener, KeyListener, ControllerListener
{
}
