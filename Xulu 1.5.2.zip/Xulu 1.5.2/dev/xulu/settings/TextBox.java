// 
// Decompiled by Procyon v0.5.36
// 

package dev.xulu.settings;

public class TextBox
{
    String text;
    
    public TextBox(final String text) {
        this.text = text;
    }
    
    public String getText() {
        return this.text;
    }
    
    public void setText(final String text) {
        this.text = text;
    }
}
