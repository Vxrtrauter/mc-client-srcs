// 
// Decompiled by Procyon v0.5.36
// 

package dev.xulu.clickgui;

public interface Labeled
{
    String getLabel();
}
