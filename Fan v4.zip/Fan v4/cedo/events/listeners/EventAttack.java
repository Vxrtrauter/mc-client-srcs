package cedo.events.listeners;

import cedo.events.Event;

public class EventAttack extends Event<EventAttack> {
}
