package cedo.events.listeners;

import cedo.events.Event;

public class EventItemUse extends Event<EventItemUse> {
}
