package cedo.events.listeners;

import cedo.events.Event;

public class EventSafeWalk extends Event<EventSafeWalk> {
}
