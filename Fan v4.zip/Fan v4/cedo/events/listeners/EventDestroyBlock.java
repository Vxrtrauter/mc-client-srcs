package cedo.events.listeners;

import cedo.events.Event;

public class EventDestroyBlock extends Event<EventDestroyBlock> {
}
