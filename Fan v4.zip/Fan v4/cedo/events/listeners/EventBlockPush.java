package cedo.events.listeners;

import cedo.events.Event;

public class EventBlockPush extends Event<EventBlockPush> {
}
