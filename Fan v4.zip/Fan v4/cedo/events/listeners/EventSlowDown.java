package cedo.events.listeners;

import cedo.events.Event;

/**
 * <p>EventSlowDown class.</p>
 *
 * @author Joseph Robinson
 * @version $Id: $Id
 */
public class EventSlowDown extends Event<EventSlowDown> {
}
