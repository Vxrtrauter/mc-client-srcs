package splash.client.events.player;

import me.hippo.systems.lwjeb.event.Cancelable;

public class EventRenderInsideBlock extends Cancelable {

}
