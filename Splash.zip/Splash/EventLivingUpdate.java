package splash.client.events.player;

import me.hippo.systems.lwjeb.event.MultiStage;

/**
 * Author: Ice
 * Created: 22:00, 10-Jun-20
 * Project: Client
 */
public class EventLivingUpdate extends MultiStage {
}
