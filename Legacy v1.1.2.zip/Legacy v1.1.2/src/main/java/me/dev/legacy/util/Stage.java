package me.dev.legacy.util;

public enum Stage {
    PRE,
    POST
}
