package me.dev.legacy.util;

public interface IStageable {

    Stage getStage();
    void setStage(Stage stage);

}
