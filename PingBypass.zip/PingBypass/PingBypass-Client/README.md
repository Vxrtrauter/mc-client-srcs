# PingBypassClient

PingBypassClient or 3arthh4ck (at least a dumbed down version of it) is a Client that allows you to connect to PingBypass (https://github.com/3arthqu4ke/PingBypass) proxies.

## Installation
- Install Minecraft 1.12.2 and forge for that version, then drop the jar into your mods folder.

## Usage
- The clients prefix is + and, especially if you managed to setup PingBypass, the commandsystem should be self explanatory.
- Typing "+S-AutoCrystal toggle" should be all you need after you connected to PingBypass

## Configs
TBD

## License
The content of this project is licensed under the [MIT license](LICENSE).

