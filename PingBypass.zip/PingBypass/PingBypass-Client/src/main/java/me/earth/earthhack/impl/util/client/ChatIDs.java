package me.earth.earthhack.impl.util.client;

public class ChatIDs
{
    public static final int TOTEM_POPS = 1000;
    public static final int MODULE = 2000;
    public static final int COMMAND = 3000;
    public static final int FRIEND = 4000;
    public static final int FRIEND_COMMAND = 5000;
    public static final int PINGBYPASS = 6000;
}
