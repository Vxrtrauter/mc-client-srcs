package me.earth.earthhack.impl.modules.client.pingbypass.submodules.sSafety.modes;

public enum UpdateMode
{
    Tick,
    Fast
}
