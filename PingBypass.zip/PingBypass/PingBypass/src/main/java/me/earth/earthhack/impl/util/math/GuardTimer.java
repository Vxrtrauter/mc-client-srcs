package me.earth.earthhack.impl.util.math;

/**
 * A simple implementation of the ITimer interface.
 * Using a StopWatch to prevent degeneration of the
 * timer after waiting for longer periods of time.
 *
 * I'm still not sure if I'm not just stupid and
 * there's a way easier way...
 */
public class GuardTimer implements DiscreteTimer
{
    private final StopWatch guard = new StopWatch();
    private final long interval;
    private final long guardDelay;
    private long delay;
    private long time;

    public GuardTimer()
    {
        this(1000);
    }

    public GuardTimer(long guardDelay)
    {
        this(guardDelay, 10);
    }

    public GuardTimer(long guardDelay, long interval)
    {
        this.guardDelay = guardDelay;
        this.interval = interval;
    }

    @Override
    public boolean passed(long ms)
    {
        return ms == 0 || System.currentTimeMillis() - time >= ms;
    }

    @Override
    public DiscreteTimer reset(long ms)
    {
        if (ms <= interval || this.delay != ms || guard.passed(guardDelay))
        {
            this.delay = ms;
            reset();
        }
        else
        {
            time = ms + time;
        }

        return this;
    }

    /**
     * Hard resets this timer to System.nanoTime()
     * and the underlying guard StopWatch.
     */
    public void reset()
    {
        time = System.currentTimeMillis();
        guard.reset();
    }

}

