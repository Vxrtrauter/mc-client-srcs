package me.earth.earthhack.impl.event.events;

public class TickEvent
{

}
