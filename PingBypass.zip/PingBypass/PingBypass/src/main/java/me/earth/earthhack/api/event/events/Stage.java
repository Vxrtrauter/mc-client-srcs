package me.earth.earthhack.api.event.events;

public enum Stage
{
    PRE,
    POST
}
