package me.earth.pingbypass.mixin.ducks;

public interface IEntityPlayerSP
{
    boolean hasValidHealth();
}
