package me.earth.earthhack.api.module;

public enum Category
{
    Combat,
    Misc,
    Render,
    Movement,
    Player,
    Client
}
