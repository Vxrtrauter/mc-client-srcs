package com.thealtening.utils;

import com.thealtening.domain.Account;

public class UserSkin {

    private final Account account;

    public UserSkin(Account account) {
        this.account = account;
    }

}
