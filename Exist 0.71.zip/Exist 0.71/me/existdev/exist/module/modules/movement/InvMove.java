package me.existdev.exist.module.modules.movement;

import me.existdev.exist.module.Module;

public class InvMove extends Module {
   public InvMove() {
      super("InvMove", 0, Module.Category.Movement);
   }
}
