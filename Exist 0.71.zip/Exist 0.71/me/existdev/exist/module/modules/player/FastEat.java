package me.existdev.exist.module.modules.player;

import me.existdev.exist.module.Module;

public class FastEat extends Module {
   public FastEat() {
      super("FastEat", 0, Module.Category.Player);
   }
}
