package com.darkmagician6.eventapi.events;

public interface Typed {
   byte getType();
}
