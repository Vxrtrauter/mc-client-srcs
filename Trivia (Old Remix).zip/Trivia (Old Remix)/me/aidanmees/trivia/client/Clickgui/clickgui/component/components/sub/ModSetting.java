package me.aidanmees.trivia.client.Clickgui.clickgui.component.components.sub;

import me.aidanmees.trivia.client.Clickgui.clickgui.component.Component;

public abstract class ModSetting {
	
	public abstract Component createComponent();
	
}
