package me.aidanmees.trivia.client.bungeehack;

import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.network.AbstractPacket;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.Packet;
import net.minecraft.network.handshake.client.C00Handshake;


public class hhasd
implements SCMC
{




}