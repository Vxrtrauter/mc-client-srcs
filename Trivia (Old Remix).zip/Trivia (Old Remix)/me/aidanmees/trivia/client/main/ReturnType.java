package me.aidanmees.trivia.client.main;

public enum ReturnType {

	NAME, MODULE, KEYBOARD

}
