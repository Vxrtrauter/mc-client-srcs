package me.aidanmees.trivia.client.tools;

public class TimeHelper {

}
