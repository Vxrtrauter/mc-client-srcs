/*package me.aidanmees.trivia.client.commands;

import me.aidanmees.trivia.client.main.trivia;
import me.aidanmees.trivia.client.modules.HighJump;

public class CommandSpider extends Command {

	@Override
	public void run(String[] commands) {
	}
	@Override
	public String getActivator() {
		return ".jump";
	}

	@Override
	public String getSyntax() {
		return ".jump <jumps>";
	}

	@Override
	public String getDesc() {
		return "This only works for a small amount of people RIP!";
	}
}
*/