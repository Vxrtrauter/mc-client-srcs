package me.aidanmees.trivia.client.module.state;

public enum Category {

	COMBAT, MOVEMENT, RENDER, MISC, MINIGAMES, INFO, HIDDEN, AUTOMATION, LEGIT, EXPLOITS, PLAYER,  WORLD, BYPASSES

}
