package me.aidanmees.trivia.client.modules.Render;

import org.lwjgl.input.Keyboard;

import me.aidanmees.trivia.client.module.state.Category;
import me.aidanmees.trivia.module.Module;

public class SignSploit extends Module {

	public SignSploit() {
		super("SignSploit", Keyboard.KEY_NONE, Category.HIDDEN, "Disables sign rendering, usesfull for crashsign.");
	}

	@Override
	public void onDisable() {

		super.onDisable();
	}

	@Override
	public void onEnable() {

		super.onEnable();
	}

	@Override
	public void onUpdate() {

		super.onUpdate();
	}

	
}
