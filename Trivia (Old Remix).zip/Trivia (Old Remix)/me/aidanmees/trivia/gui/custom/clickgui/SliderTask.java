package me.aidanmees.trivia.gui.custom.clickgui;

public abstract class SliderTask {

	public abstract void task(Slider slider);

}
