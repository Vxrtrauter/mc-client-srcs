package me.aidanmees.trivia.gui.custom.clickgui;

public enum ValueFormat {
	
	PERCENT, DECIMAL, INT
	
}
