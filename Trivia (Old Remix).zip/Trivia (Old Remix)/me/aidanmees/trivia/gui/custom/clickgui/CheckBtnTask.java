package me.aidanmees.trivia.gui.custom.clickgui;

public abstract class CheckBtnTask {
	
	public abstract void task(SettingCheckBtn checkBtn);
	
}
