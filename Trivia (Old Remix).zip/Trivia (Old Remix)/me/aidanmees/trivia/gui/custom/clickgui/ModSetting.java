package me.aidanmees.trivia.gui.custom.clickgui;

public abstract class ModSetting {
	
	public abstract Component createComponent();
	
}
