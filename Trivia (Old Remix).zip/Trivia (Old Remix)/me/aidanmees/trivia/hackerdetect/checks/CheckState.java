package me.aidanmees.trivia.hackerdetect.checks;

public enum CheckState {
	
	VIOLATION, IDLE, RESET
	
}
