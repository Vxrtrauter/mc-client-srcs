package net.mcleaks;

public abstract interface Callback<T> {
	public abstract void done(T paramT);
}
