// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.gui.spectator;

public interface ISpectatorMenuRecipient
{
    void func_175257_a(final SpectatorMenu p0);
}
