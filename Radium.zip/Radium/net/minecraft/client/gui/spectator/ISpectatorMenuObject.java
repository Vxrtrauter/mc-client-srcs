// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.client.gui.spectator;

import net.minecraft.util.IChatComponent;

public interface ISpectatorMenuObject
{
    void func_178661_a(final SpectatorMenu p0);
    
    IChatComponent getSpectatorName();
    
    void func_178663_a(final float p0, final int p1);
    
    boolean func_178662_A_();
}
