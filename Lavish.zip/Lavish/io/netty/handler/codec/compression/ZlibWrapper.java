// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.handler.codec.compression;

public enum ZlibWrapper
{
    ZLIB, 
    GZIP, 
    NONE, 
    ZLIB_OR_NONE;
}
