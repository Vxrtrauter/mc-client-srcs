// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.handler.codec.socks;

public enum SocksRequestType
{
    INIT, 
    AUTH, 
    CMD, 
    UNKNOWN;
}
