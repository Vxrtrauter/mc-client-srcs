// 
// Decompiled by Procyon v0.5.36
// 

package io.netty.handler.ssl;

public enum SslProvider
{
    JDK, 
    OPENSSL;
}
