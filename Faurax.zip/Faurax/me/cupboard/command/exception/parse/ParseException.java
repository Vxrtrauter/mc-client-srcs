package me.cupboard.command.exception.parse;

public final class ParseException extends Exception
{
    public ParseException(final String message) {
        super(message);
    }
}
