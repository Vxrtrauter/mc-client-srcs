package me.rigamortis.faurax.hooks;

public class NetworkManagerHook
{
}
