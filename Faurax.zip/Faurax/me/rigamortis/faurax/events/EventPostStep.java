package me.rigamortis.faurax.events;

import com.darkmagician6.eventapi.events.callables.*;
import com.darkmagician6.eventapi.events.*;

public class EventPostStep extends EventCancellable implements Event
{
}
