package me.Corbis.Execution.Music.Songs;

import me.Corbis.Execution.Music.Song;

public class StiletoStateOfMind extends Song {

    public StiletoStateOfMind(){
        super("StiletoStateOfMind", "stiletostateofmind.wav");
    }

    @Override
    public void play() {
        super.play();
    }
}
