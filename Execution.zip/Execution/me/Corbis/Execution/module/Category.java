package me.Corbis.Execution.module;

public enum Category {
    COMBAT, MOVEMENT, PLAYER,RENDER, EXPLOIT, MISC, WORLD, TARGETS
}
