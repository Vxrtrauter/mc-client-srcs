package me.Corbis.Execution.event.events;

import me.Corbis.Execution.event.Event;

public class EventUpdate extends Event {
}
