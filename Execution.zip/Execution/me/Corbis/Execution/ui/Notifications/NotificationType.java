package me.Corbis.Execution.ui.Notifications;

public enum NotificationType {
    INFO, WARNING
}
