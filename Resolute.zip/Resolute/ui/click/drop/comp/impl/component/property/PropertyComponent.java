// 
// Decompiled by Procyon v0.5.36
// 

package vip.Resolute.ui.click.drop.comp.impl.component.property;

import vip.Resolute.settings.Setting;

public interface PropertyComponent
{
    Setting getProperty();
}
