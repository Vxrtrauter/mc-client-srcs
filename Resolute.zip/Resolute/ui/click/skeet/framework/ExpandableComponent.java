// 
// Decompiled by Procyon v0.5.36
// 

package vip.Resolute.ui.click.skeet.framework;

public interface ExpandableComponent
{
    float getExpandedX();
    
    float getExpandedY();
    
    float getExpandedWidth();
    
    float getExpandedHeight();
    
    void setExpanded(final boolean p0);
    
    boolean isExpanded();
}
