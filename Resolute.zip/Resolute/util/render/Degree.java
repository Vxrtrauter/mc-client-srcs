// 
// Decompiled by Procyon v0.5.36
// 

package vip.Resolute.util.render;

public class Degree
{
    public String text;
    public int type;
    
    public Degree(final String s, final int t) {
        this.text = s;
        this.type = t;
    }
}
