package me.ihaq.iClient.event.events;

import me.ihaq.iClient.event.Event;

/**
 * Created by Hexeption on 07/01/2017.
 */
public class EventUpdate extends Event {

}
