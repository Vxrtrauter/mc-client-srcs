package com.sun.jna;

public abstract interface TypeConverter
        extends FromNativeConverter, ToNativeConverter {
}




