package com.jcraft.jorbis;

class InfoMode {
    int blockflag;
    int windowtype;
    int transformtype;
    int mapping;
}




