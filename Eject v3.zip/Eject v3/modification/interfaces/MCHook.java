package modification.interfaces;

import net.minecraft.client.Minecraft;

public abstract interface MCHook {
    public static final Minecraft MC = ;
}




