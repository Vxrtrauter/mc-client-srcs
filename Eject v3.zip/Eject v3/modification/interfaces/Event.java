package modification.interfaces;

public abstract interface Event {
}




