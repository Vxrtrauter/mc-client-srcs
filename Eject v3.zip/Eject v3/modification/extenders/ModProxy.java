package modification.extenders;

public final class ModProxy {
    public String ip;
    public int port;

    public ModProxy(String paramString, int paramInt) {
        this.ip = paramString;
        this.port = paramInt;
    }
}




