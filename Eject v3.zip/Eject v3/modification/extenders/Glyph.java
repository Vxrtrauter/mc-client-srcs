package modification.extenders;

public final class Glyph {
    public int x;
    public int y;
    public int width;
    public int height;
}




