package modification.modules.visuals;

import modification.enummerates.Category;
import modification.extenders.Module;
import modification.interfaces.Event;

public final class NoHurtCam
        extends Module {
    public NoHurtCam(String paramString, Category paramCategory) {
        super(paramString, paramCategory);
    }

    protected void onActivated() {
    }

    public void onEvent(Event paramEvent) {
    }

    protected void onDeactivated() {
    }
}




