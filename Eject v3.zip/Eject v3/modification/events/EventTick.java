package modification.events;

import modification.interfaces.Event;

public final class EventTick
        implements Event {
}




