package modification.events;

import modification.interfaces.Event;

public final class EventShouldAttack
        implements Event {
}




