package modification.events;

import modification.interfaces.Event;

public final class EventSwingItem
        implements Event {
    public boolean canceled;
}




