package modification.events;

import modification.interfaces.Event;

public final class EventUpdate
        implements Event {
}




