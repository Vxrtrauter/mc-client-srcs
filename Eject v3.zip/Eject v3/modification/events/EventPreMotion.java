package modification.events;

import modification.interfaces.Event;

public final class EventPreMotion
        implements Event {
    public EventPreMotion(float paramFloat1, float paramFloat2) {
    }
}




