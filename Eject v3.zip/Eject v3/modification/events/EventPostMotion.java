package modification.events;

import modification.interfaces.Event;

public final class EventPostMotion
        implements Event {
}




