package io.netty.util.concurrent;

public abstract interface ScheduledFuture<V>
        extends Future<V>, java.util.concurrent.ScheduledFuture<V> {
}




