package com.mentalfrostbyte.jello.event.types;

public enum EventType2
{
  PRE,  POST;
}

