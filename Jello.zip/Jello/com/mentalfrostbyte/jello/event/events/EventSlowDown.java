package com.mentalfrostbyte.jello.event.events;

import com.mentalfrostbyte.jello.event.events.callables.EventCancellable;

import net.minecraft.util.BlockPos;

public class EventSlowDown
extends EventCancellable {
   
    
}

