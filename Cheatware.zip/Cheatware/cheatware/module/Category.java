package cheatware.module;

public enum Category {
    COMBAT, MOVEMENT, RENDER, PLAYER
}
