package me.robbanrobbin.jigsaw.client.main;

public enum ReturnType {

	NAME, MODULE, KEYBOARD

}
