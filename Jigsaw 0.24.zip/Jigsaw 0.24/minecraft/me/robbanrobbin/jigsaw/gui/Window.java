package me.robbanrobbin.jigsaw.gui;

import net.minecraft.client.gui.Gui;

public class Window extends Gui {
	
	public int x;
	public int y;
	
	public int width;
	public int height;
	
	public Window() {
		
	}
	
	public void update() {
		
	}
	
	public void draw() {
		
	}
	
}
