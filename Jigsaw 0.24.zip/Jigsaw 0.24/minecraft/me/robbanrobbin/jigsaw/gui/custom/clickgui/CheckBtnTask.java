package me.robbanrobbin.jigsaw.gui.custom.clickgui;

public abstract class CheckBtnTask {
	
	public abstract void task(SettingCheckBtn checkBtn);
	
}
