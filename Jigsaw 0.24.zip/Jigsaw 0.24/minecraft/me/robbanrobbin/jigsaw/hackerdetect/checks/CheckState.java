package me.robbanrobbin.jigsaw.hackerdetect.checks;

public enum CheckState {
	
	VIOLATION, IDLE, RESET
	
}
