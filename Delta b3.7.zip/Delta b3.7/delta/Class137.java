/*
 * Decompiled with CFR 0.150.
 */
package delta;

public interface Class137 {
    public static final boolean still$;

    public boolean _plymouth(Class137 var1);

    public boolean _fixtures();

    public Class137 _actress();

    public boolean _elements();

    public String _settle();

    public boolean _computer();

    public boolean _northern();
}

