/*
 * Decompiled with CFR 0.150.
 */
package delta;

public class Class3<T extends Number> {
    private T honors$;
    private T drilling$;
    private T livecam$;

    public T _poster() {
        return this.honors$;
    }

    public Class3 _sitemap(T t) {
        this.drilling$ = t;
        return this;
    }

    public Class3 _paradise(T t) {
        this.honors$ = t;
        return this;
    }

    public T _aspects() {
        return this.livecam$;
    }

    public T _nervous() {
        return this.drilling$;
    }

    public Class3(T t, T t2, T t3) {
        this.honors$ = t;
        this.livecam$ = t2;
        this.drilling$ = t3;
    }

    public Class3 _notebook(T t) {
        this.livecam$ = t;
        return this;
    }
}

