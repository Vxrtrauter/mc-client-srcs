/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  delta.OVYt$968L
 */
package delta;

import delta.OVYt;

public final class Class115
extends Enum<Class115> {
    private String lowest$;
    private String senior$;
    private static final Class115[] preserve$;
    public static final /* enum */ Class115 electric$;
    public static final /* enum */ Class115 signed$;
    public static final /* enum */ Class115 stress$;
    private static String[] tamil$;
    public static final /* enum */ Class115 surprise$;

    public String _catering() {
        if (this.senior$ == null || this.senior$ == OVYt.968L.FS1x((String)tamil$[0], (int)861444997)) {
            String string = OVYt.968L.FS1x((String)tamil$[1], (int)1947480544);
            if (this._emily()) {
                if (this == stress$) {
                    string = string + OVYt.968L.FS1x((String)tamil$[2], (int)-1579669719);
                }
                string = string + OVYt.968L.FS1x((String)tamil$[3], (int)-1738786725);
            } else {
                string = string + OVYt.968L.FS1x((String)tamil$[4], (int)2124881989);
            }
            if (this._commonly()) {
                string = string + OVYt.968L.FS1x((String)tamil$[5], (int)-595661223);
            }
            this.senior$ = string;
        }
        return this.senior$;
    }

    public boolean _soonest() {
        return (this == stress$ || this == surprise$ ? 75 - 100 + 16 - 2 + 12 : 140 - 205 + 71 - 10 + 4) != 0;
    }

    public String _realty() {
        return this.lowest$;
    }

    public static Class115 _carlo(String string) {
        return Enum.valueOf(Class115.class, string);
    }

    public boolean _commonly() {
        return (this == surprise$ || this == signed$ || this == stress$ ? 96 - 138 + 11 - 10 + 42 : 128 - 216 + 16 - 15 + 87) != 0;
    }

    public static Class115[] _reader() {
        return (Class115[])preserve$.clone();
    }

    static {
        Class115._mason();
        surprise$ = new Class115(OVYt.968L.FS1x((String)tamil$[7], (int)-736519825));
        stress$ = new Class115(OVYt.968L.FS1x((String)tamil$[9], (int)1918746992));
        signed$ = new Class115(OVYt.968L.FS1x((String)tamil$[11], (int)-1716108041));
        electric$ = new Class115(OVYt.968L.FS1x((String)tamil$[13], (int)2435796));
        Class115[] arrclass115 = new Class115[234 - 244 + 117 + -103];
        arrclass115[114 - 160 + 19 + 27] = surprise$;
        arrclass115[39 - 47 + 44 - 19 + -16] = stress$;
        arrclass115[251 - 403 + 258 - 176 + 72] = signed$;
        arrclass115[115 - 152 + 71 + -31] = electric$;
        preserve$ = arrclass115;
    }

    private Class115(String string2) {
        this.lowest$ = string2;
    }

    private static void _mason() {
        tamil$ = new String[]{"", "", "\u2759", "\u381a", "\u2006", "\uee74\uee0d", "\u8dbc\u8dbf\u8dad\u8da9\u8da3\u8dad\u8dba", "\u993b\u9938\u992a\u992e\u9924\u992a\u993d", "\u65a2\u65a0\u65b7\u65b3\u65b5\u65b7\u65bc\u65a6\u65ad\u65a0\u65b7\u65b6\u65b7\u65b4\u65bb\u65bc\u65b7", "\uc120\uc122\uc135\uc131\uc137\uc135\uc13e\uc124\uc12f\uc122\uc135\uc134\uc135\uc136\uc139\uc13e\uc135", "\ubad1\ubad7\ubad5\ubade\ubac4\ubacf\ubac2\ubad5\ubac4\ubac2\ubad1\ubade\ubac3\ubad6\ubadf\ubac2\ubadd", "\u44b6\u44b0\u44b2\u44b9\u44a3\u44a8\u44a5\u44b2\u44a3\u44a5\u44b6\u44b9\u44a4\u44b1\u44b8\u44a5\u44ba", "\uf825\uf823\uf821\uf82a\uf830\uf83b\uf82a\uf82b\uf83b\uf836\uf821\uf830\uf836\uf825\uf82a\uf837\uf822\uf82b\uf836\uf829", "\u2a95\u2a93\u2a91\u2a9a\u2a80\u2a8b\u2a9a\u2a9b\u2a8b\u2a86\u2a91\u2a80\u2a86\u2a95\u2a9a\u2a87\u2a92\u2a9b\u2a86\u2a99"};
    }

    public boolean _emily() {
        return (this == signed$ || this == electric$ || this == stress$ ? 126 - 177 + 42 - 27 + 37 : 79 - 125 + 56 + -10) != 0;
    }
}

