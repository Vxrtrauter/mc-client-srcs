/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  me.xtrm.delta.api.setting.ISetting
 */
package delta;

import delta.Class147;
import delta.Class178;
import delta.Class69;
import me.xtrm.delta.api.setting.ISetting;

public class Class15
extends Class178 {
    @Override
    public void _start(int n, int n2, float f) {
        super._start(n, n2, f);
        Class69.details$._college(this.jR2K.getLabelString(), this.cgEg + 3.0, this.Z085 + this.SHPn / 2.0 - (double)(Class69.details$._rwanda() / (116 - 140 + 14 + 12)) + 1.0, 136 - 142 + 91 + -86);
    }

    public Class15(ISetting iSetting, Class147 class147) {
        super(iSetting, class147);
    }
}

