/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  me.xtrm.delta.api.setting.ISetting
 */
package delta;

import delta.Class147;
import delta.Class178;
import me.xtrm.delta.api.setting.ISetting;

public class Class165
extends Class178 {
    @Override
    public void _start(int n, int n2, float f) {
    }

    public Class165(ISetting iSetting, Class147 class147) {
        super(iSetting, class147);
    }
}

