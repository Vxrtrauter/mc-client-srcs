/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  delta.OVYt$968L
 */
package delta;

import delta.OVYt;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Method;
import java.net.URL;

public class Class206 {
    private static long insider$;
    private static long hotels$;
    private static Method global$;
    private static Method headers$;
    private static Method albums$;
    private static final boolean traffic$;
    private static Object cameras$;
    private static Method kinase$;
    private static Field austin$;
    private static String[] urgent$;
    private static long advisory$;
    private static Method thompson$;

    public static void _debian(AccessibleObject accessibleObject) throws ReflectiveOperationException {
        if (traffic$) {
            accessibleObject.setAccessible(46 - 49 + 44 + -40);
        } else {
            if (austin$ == null) {
                austin$ = AccessibleObject.class.getDeclaredField(OVYt.968L.FS1x((String)urgent$[26], (int)-348704734));
                Object[] arrobject = new Object[78 - 120 + 18 - 8 + 33];
                arrobject[180 - 336 + 31 + 125] = austin$;
                hotels$ = (Long)global$.invoke(cameras$, arrobject);
                Class206._debian(austin$);
            }
            Object[] arrobject = new Object[257 - 468 + 326 + -112];
            arrobject[190 - 378 + 37 + 151] = accessibleObject;
            arrobject[261 - 505 + 362 + -117] = hotels$;
            arrobject[210 - 396 + 193 + -5] = 254 - 297 + 269 - 183 + -42;
            kinase$.invoke(cameras$, arrobject);
        }
    }

    private static void _seating() {
        urgent$ = new String[]{"\u8e9b\u8e8d\u8e9e", "\u99b1\u998a\u9985\u9986\u9988\u9981\u99c4\u9990\u998b\u99c4\u9982\u998d\u998a\u9980\u99c4\u99b1\u99b6\u99a8\u99a7\u9988\u9985\u9997\u9997\u99b4\u9985\u9990\u998c\u99c4\u9982\u998d\u9981\u9988\u9980\u99c4\u998d\u998a\u99c4\u9990\u998c\u9981\u99c4\u9987\u9991\u9996\u9996\u9981\u998a\u9990\u99c4\u9987\u9988\u9985\u9997\u9997\u99c4\u9988\u998b\u9985\u9980\u9981\u9996", "\ufbdb\ufbd0\ufbc7\ufbd0\ufb9f\ufbc7\ufbd4\ufbc3\ufbc2\ufbd8\ufbde\ufbdf", "\u477a\u4765", "\u8bed\u8beb\u8bf0\u8bb0\u8bf3\u8bf7\u8bed\u8bfd\u8bb0\u8bcb\u8bcc\u8bd2\u8bdd\u8bf2\u8bff\u8bed\u8bed\u8bce\u8bff\u8bea\u8bf6", "\ud3ba\ud3b4\ud3bb\ud3fe\ud3b9\ud3be\ud3a4\ud3b5\ud3a2\ud3be\ud3b1\ud3bc\ud3fe\ud3bc\ud3bf\ud3b1\ud3b4\ud3b5\ud3a2\ud3fe\ud385\ud382\ud39c\ud393\ud3bc\ud3b1\ud3a3\ud3a3\ud380\ud3b1\ud3a4\ud3b8", "\u9e4f\u9e74\u9e7b\u9e78\u9e76\u9e7f\u9e3a\u9e6e\u9e75\u9e3a\u9e7c\u9e73\u9e74\u9e7e\u9e3a\u9e4f\u9e48\u9e56\u9e59\u9e76\u9e7b\u9e69\u9e69\u9e4a\u9e7b\u9e6e\u9e72\u9e3a\u9e79\u9e76\u9e7b\u9e69\u9e69", "\u37f2\u37f4\u37ef\u37af\u37ec\u37e8\u37f2\u37e2\u37af\u37d4\u37ef\u37f2\u37e0\u37e7\u37e4", "\u118f\u1193\u119e\u11ae\u1195\u1188\u119a\u119d\u119e", "\u3edb\u3ed6\u3ede\u3ed1\u3ed7\u3ec0\u3ef2\u3edd\u3ed1\u3ed8\u3ed0\u3efb\u3ed2\u3ed2\u3ec7\u3ed1\u3ec0", "\u9d63\u9d66\u9d67\u9d51\u9d7c\u9d7c\u9d7f\u9d76\u9d72\u9d7d", "\u58ab\u58ae\u58af\u5894\u58b9\u58b1\u58be\u58b8\u58af\u588d\u58b4\u58b7\u58ba\u58af\u58b2\u58b7\u58be", "\u8b14\u8b13\u8b06\u8b13\u8b0e\u8b04\u8b21\u8b0e\u8b02\u8b0b\u8b03\u8b28\u8b01\u8b01\u8b14\u8b02\u8b13", "\u8e0e\u8e00\u8e0f\u8e4a\u8e0d\u8e0a\u8e10\u8e01\u8e16\u8e0a\u8e05\u8e08\u8e4a\u8e09\u8e0b\u8e00\u8e11\u8e08\u8e01\u8e4a\u8e2d\u8e08\u8e08\u8e01\u8e03\u8e05\u8e08\u8e25\u8e07\u8e07\u8e01\u8e17\u8e17\u8e28\u8e0b\u8e03\u8e03\u8e01\u8e16", "\ub467\ub464\ub46c\ub46c\ub46e\ub479", "\u91b6\u91a7\u918c\u919b\u918c\u91d4\u91ab\u9184\u9195\u91b0\u91d7\u91cd\u91b8\u9183\u918c\u918f\u9181\u9188\u91cd\u9199\u9182\u91cd\u9189\u9184\u919e\u918c\u918f\u9181\u9188\u91cd\u9184\u9183\u919b\u918c\u9181\u9184\u9189\u91cd\u918c\u918e\u918e\u9188\u919e\u919e\u91cd\u9181\u9182\u918a\u918a\u9184\u9183\u918a", "\ub707\ub705\ub714\ub72d\ub70f\ub704\ub715\ub70c\ub705", "\u6e37\u6e3c\u6e2b\u6e3c\u6e73\u6e31\u6e3c\u6e33\u6e3a\u6e73\u6e10\u6e32\u6e39\u6e28\u6e31\u6e38", "\u0e1a\u0e1b\u0e0d\u0e1d\u0e0c\u0e17\u0e0e\u0e0a\u0e11\u0e0c", "\u3b3d\u3b36\u3b21\u3b36\u3b79\u3b3b\u3b36\u3b39\u3b30\u3b79\u3b3a\u3b38\u3b33\u3b22\u3b3b\u3b32\u3b79\u3b1a\u3b38\u3b33\u3b22\u3b3b\u3b32\u3b13\u3b32\u3b24\u3b34\u3b25\u3b3e\u3b27\u3b23\u3b38\u3b25", "\uf697\uf688\uf69d\uf696", "\u0937\u0935\u0924\u091f\u0932\u093a\u0935\u0933\u0924", "\ue717\ue706\ue72d\ue73a\ue72d\ue775\ue70a\ue725\ue734\ue711\ue776\ue76c\ue719\ue722\ue72d\ue72e\ue720\ue729\ue76c\ue738\ue723\ue76c\ue728\ue725\ue73f\ue72d\ue72e\ue720\ue729\ue76c\ue73e\ue729\ue72a\ue720\ue729\ue72f\ue738\ue725\ue723\ue722\ue73f\ue76c\ue72f\ue724\ue729\ue72f\ue727\ue73f", "\u2c99\u2cb5\u2caf\u2cb6\u2cbe\u2cb4\u2cfd\u2cae\u2cfa\u2cb3\u2cb4\u2cb3\u2cae\u2cfa\u2cb8\u2ca3\u2caa\u2cbb\u2ca9\u2ca9\u2cfb", "\ub413\ub411\ub400\ub421\ub426\ub438\ub407", "\u5493\u54bf\u54a5\u54bc\u54b4\u54be\u54f7\u54a4\u54f0\u54b9\u54be\u54b9\u54a4\u54f0\u54b2\u54a9\u54a0\u54b1\u54a3\u54a3\u54f1", "\u304d\u3054\u3047\u3050\u3050\u304b\u3046\u3047"};
    }

    public static void _brokers(Class<?> class_) throws ReflectiveOperationException {
        if (!traffic$ && thompson$ != null) {
            Object object = headers$.invoke(class_, new Object[167 - 271 + 33 + 71]);
            Object[] arrobject = new Object[167 - 177 + 13 - 2 + 1];
            arrobject[94 - 96 + 70 - 14 + -54] = object;
            arrobject[197 - 383 + 109 - 69 + 147] = advisory$;
            object = thompson$.invoke(cameras$, arrobject);
            Object[] arrobject2 = new Object[179 - 247 + 94 + -23];
            arrobject2[202 - 359 + 153 + 4] = object;
            arrobject2[188 - 341 + 238 - 144 + 60] = insider$;
            arrobject2[54 - 84 + 31 + 1] = 209 - 323 + 190 - 17 + -58;
            kinase$.invoke(cameras$, arrobject2);
        }
    }

    static {
        Class<?> class_;
        Class206._seating();
        traffic$ = System.getProperty(OVYt.968L.FS1x((String)urgent$[2], (int)-832635983)).startsWith(OVYt.968L.FS1x((String)urgent$[3], (int)397821771));
        try {
            class_ = Class.forName(OVYt.968L.FS1x((String)urgent$[4], (int)270764958));
        }
        catch (ClassNotFoundException classNotFoundException) {
            try {
                class_ = Class.forName(OVYt.968L.FS1x((String)urgent$[5], (int)-357641264));
            }
            catch (ClassNotFoundException classNotFoundException2) {
                throw new InternalError(OVYt.968L.FS1x((String)urgent$[6], (int)-1783914982), classNotFoundException2);
            }
        }
        if (!traffic$) {
            try {
                GenericDeclaration genericDeclaration;
                GenericDeclaration genericDeclaration2;
                Class<?> class_2 = Class.forName(OVYt.968L.FS1x((String)urgent$[7], (int)184432513));
                Field field = class_2.getDeclaredField(OVYt.968L.FS1x((String)urgent$[8], (int)1179455995));
                field.setAccessible(266 - 466 + 71 + 130);
                cameras$ = field.get(null);
                Class[] arrclass = new Class[25 - 33 + 7 - 3 + 5];
                arrclass[26 - 45 + 45 + -26] = Field.class;
                global$ = class_2.getDeclaredMethod(OVYt.968L.FS1x((String)urgent$[9], (int)-1201717580), arrclass);
                Class[] arrclass2 = new Class[149 - 161 + 78 - 27 + -36];
                arrclass2[192 - 278 + 163 - 12 + -65] = Object.class;
                arrclass2[237 - 289 + 72 + -19] = Long.TYPE;
                arrclass2[174 - 345 + 248 - 201 + 126] = Boolean.TYPE;
                kinase$ = class_2.getDeclaredMethod(OVYt.968L.FS1x((String)urgent$[10], (int)-125133549), arrclass2);
                try {
                    Class[] arrclass3 = new Class[91 - 164 + 161 - 25 + -60];
                    arrclass3[273 - 323 + 78 + -28] = Object.class;
                    arrclass3[149 - 170 + 24 - 2 + 0] = Long.TYPE;
                    arrclass3[212 - 320 + 197 + -87] = Object.class;
                    genericDeclaration2 = class_2.getDeclaredMethod(OVYt.968L.FS1x((String)urgent$[11], (int)93477083), arrclass3);
                    Class[] arrclass4 = new Class[201 - 398 + 9 - 3 + 192];
                    arrclass4[98 - 180 + 19 - 15 + 78] = Field.class;
                    genericDeclaration = class_2.getDeclaredMethod(OVYt.968L.FS1x((String)urgent$[12], (int)268012391), arrclass4);
                    Class<?> class_3 = Class.forName(OVYt.968L.FS1x((String)urgent$[13], (int)624135780));
                    Field field2 = class_3.getDeclaredField(OVYt.968L.FS1x((String)urgent$[14], (int)-1082870773));
                    Object[] arrobject = new Object[213 - 373 + 344 + -183];
                    arrobject[68 - 118 + 90 - 83 + 43] = field2;
                    Long l = (Long)((Method)genericDeclaration).invoke(cameras$, arrobject);
                    Object[] arrobject2 = new Object[40 - 59 + 52 + -30];
                    arrobject2[126 - 236 + 126 + -16] = class_3;
                    arrobject2[25 - 40 + 34 - 18 + 0] = l;
                    arrobject2[41 - 63 + 47 - 16 + -7] = null;
                    ((Method)genericDeclaration2).invoke(cameras$, arrobject2);
                }
                catch (ReflectiveOperationException reflectiveOperationException) {
                    System.out.println(OVYt.968L.FS1x((String)urgent$[15], (int)-1038118419));
                }
                try {
                    headers$ = Class.class.getDeclaredMethod(OVYt.968L.FS1x((String)urgent$[16], (int)1886762848), new Class[94 - 102 + 91 + -83]);
                    genericDeclaration2 = Class.forName(OVYt.968L.FS1x((String)urgent$[17], (int)666267229));
                    Object[] arrobject = new Object[57 - 63 + 29 + -22];
                    arrobject[227 - 440 + 262 - 179 + 130] = ((Class)genericDeclaration2).getDeclaredField(OVYt.968L.FS1x((String)urgent$[18], (int)-613020034));
                    advisory$ = (Long)global$.invoke(cameras$, arrobject);
                    genericDeclaration = Class.forName(OVYt.968L.FS1x((String)urgent$[19], (int)598293335));
                    Object[] arrobject3 = new Object[104 - 177 + 94 + -20];
                    arrobject3[131 - 196 + 81 - 41 + 25] = ((Class)genericDeclaration).getDeclaredField(OVYt.968L.FS1x((String)urgent$[20], (int)-19925256));
                    insider$ = (Long)global$.invoke(cameras$, arrobject3);
                    Class[] arrclass5 = new Class[179 - 204 + 80 + -53];
                    arrclass5[192 - 292 + 230 + -130] = Object.class;
                    arrclass5[35 - 55 + 36 + -15] = Long.TYPE;
                    thompson$ = class_2.getDeclaredMethod(OVYt.968L.FS1x((String)urgent$[21], (int)-2064381616), arrclass5);
                    Class206._brokers(Class.class);
                    Class206._brokers(class_);
                }
                catch (ReflectiveOperationException reflectiveOperationException) {
                    System.out.println(OVYt.968L.FS1x((String)urgent$[22], (int)-1463687348));
                }
            }
            catch (ReflectiveOperationException reflectiveOperationException) {
                throw new InternalError(OVYt.968L.FS1x((String)urgent$[23], (int)29502682), reflectiveOperationException);
            }
        }
        try {
            albums$ = class_.getDeclaredMethod(OVYt.968L.FS1x((String)urgent$[24], (int)-695946124), new Class[102 - 173 + 8 + 63]);
            Class206._debian(albums$);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new InternalError(OVYt.968L.FS1x((String)urgent$[25], (int)-2027596592), reflectiveOperationException);
        }
    }

    public static URL[] _ralph(ClassLoader classLoader) throws ReflectiveOperationException {
        Class<?> class_ = classLoader.getClass();
        Field field = null;
        while (field == null && class_ != null) {
            try {
                field = class_.getDeclaredField(OVYt.968L.FS1x((String)urgent$[0], (int)-1919578386));
            }
            catch (ReflectiveOperationException reflectiveOperationException) {
                class_ = class_.getSuperclass();
            }
        }
        if (field == null) {
            throw new NoSuchFieldException(OVYt.968L.FS1x((String)urgent$[1], (int)2083363300));
        }
        Class206._debian(field);
        return (URL[])albums$.invoke(field.get(classLoader), new Object[236 - 356 + 278 + -158]);
    }

    public static boolean _premiere() {
        return !traffic$ ? 253 - 317 + 235 + -170 : 232 - 289 + 138 + -81;
    }

    public static boolean _sticks() {
        return traffic$;
    }
}

