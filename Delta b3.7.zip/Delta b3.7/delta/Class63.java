/*
 * Decompiled with CFR 0.150.
 */
package delta;

import java.util.ArrayList;

public class Class63 {
    public static ArrayList<String> _dressing(String ... arrstring) {
        ArrayList<String> arrayList = new ArrayList<String>();
        String[] arrstring2 = arrstring;
        int n = arrstring2.length;
        for (int i = 211 - 345 + 192 + -58; i < n; ++i) {
            String string = arrstring2[i];
            arrayList.add(string);
        }
        return arrayList;
    }
}

