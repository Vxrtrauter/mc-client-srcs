/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  me.xtrm.delta.api.setting.ISetting
 */
package delta;

import delta.Class147;
import delta.Class5;
import me.xtrm.delta.api.setting.ISetting;

public class Class178
extends Class5 {
    public ISetting graduate$;

    public Class178(ISetting iSetting, Class147 class147) {
        super(class147);
        this.graduate$ = iSetting;
    }
}

