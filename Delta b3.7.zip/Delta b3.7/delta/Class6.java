/*
 * Decompiled with CFR 0.150.
 */
package delta;

import delta.Class3;
import delta.Class87;

public class Class6<T extends Number>
extends Class3<Number> {
    public Class6(T t, T t2, T t3) {
        super(t, t2, t3);
    }

    public Class87<T> _breeds() {
        return new Class87(this._poster(), this._aspects());
    }
}

