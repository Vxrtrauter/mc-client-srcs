package me.robbanrobbin.jigsaw.client.module.state;

public enum Category {

	COMBAT, MOVEMENT, RENDER, MISC, MINIGAMES, INFO, HIDDEN, AUTOMATION, TARGET, FUN, UTILS, EXPLOITS, PLAYER, SETTINGS, WORLD, PRESETS

}
