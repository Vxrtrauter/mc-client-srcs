package me.robbanrobbin.jigsaw.gui.custom.clickgui;

public abstract class ModSetting {
	
	public abstract Component createComponent();
	
}
