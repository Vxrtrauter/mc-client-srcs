package me.robbanrobbin.jigsaw.gui;

public enum ScreenPos {

	LEFTDOWN, LEFT, LEFTUP, TOP, RIGHTUP, RIGHT, RIGHTDOWN, BOTTOM

}
