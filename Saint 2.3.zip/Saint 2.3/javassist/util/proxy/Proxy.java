package javassist.util.proxy;

public interface Proxy {
   void setHandler(MethodHandler mi);
}
