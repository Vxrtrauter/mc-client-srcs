package javassist.tools.reflect;

class CompiledClass {
   public String classname;
   public String metaobject;
   public String classobject;
}
