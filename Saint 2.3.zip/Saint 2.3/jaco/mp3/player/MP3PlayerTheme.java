package jaco.mp3.player;

public interface MP3PlayerTheme {
   void apply(MP3Player var1);
}
