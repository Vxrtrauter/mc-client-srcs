package jaco.mp3.resources;

import java.io.InputStream;

public interface JavaLayerHook {
   InputStream getResourceAsStream(String var1);
}
