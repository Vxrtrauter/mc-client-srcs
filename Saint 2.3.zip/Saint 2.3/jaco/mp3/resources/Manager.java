package jaco.mp3.resources;

public class Manager {
   public void addControl(Control c) {
   }

   public void removeControl(Control c) {
   }

   public void removeAll() {
   }
}
