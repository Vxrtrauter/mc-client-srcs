package com.gamesense.client.module;

public enum Category {
    Combat,
    Exploits,
    Movement,
    Misc,
    Render,
    HUD,
    GUI
}