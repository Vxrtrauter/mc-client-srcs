package com.gamesense.api.event;

public enum Phase {
    PRE,
    BY,
    POST
}