package me.robbanrobbin.jigsaw.gui.custom.clickgui;

import me.robbanrobbin.jigsaw.gui.custom.clickgui.layout.Layout;

public class ArrowViewWindow extends ComponentWindow {
	
	public ArrowViewWindow(Layout layout) {
		super(layout);
	}

	@Override
	public void draw() {
		
		super.draw();
	}

}
