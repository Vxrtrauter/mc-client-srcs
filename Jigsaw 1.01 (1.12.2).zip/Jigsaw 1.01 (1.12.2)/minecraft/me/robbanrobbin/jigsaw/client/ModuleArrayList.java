package me.robbanrobbin.jigsaw.client;

import java.util.ArrayList;

public class ModuleArrayList {
	
	public ArrayList<ModuleArrayListEntry> entries = new ArrayList<ModuleArrayListEntry>();
	
	
	
}
