package me.robbanrobbin.jigsaw.client.events;

public class PreFrameBufferEvent extends Event {
	
	public PreFrameBufferEvent() {
		
	}
	
}
