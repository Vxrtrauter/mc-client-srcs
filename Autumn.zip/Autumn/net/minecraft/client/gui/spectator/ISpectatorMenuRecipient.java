package net.minecraft.client.gui.spectator;

public interface ISpectatorMenuRecipient {
   void func_175257_a(SpectatorMenu var1);
}
